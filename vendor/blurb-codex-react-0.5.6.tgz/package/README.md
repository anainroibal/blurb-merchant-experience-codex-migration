# @blurb/codex-react

![CI](https://github.com/blurb/codex-react/actions/workflows/ci.yml/badge.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue)
![React](https://img.shields.io/badge/React-18-61dafb)

A themeable design system component library built with React, TypeScript, and CSS Modules. Features a token-based design system with multiple brand themes (base, blurb, rpa) powered by Style Dictionary.

For additional context, see the [Confluence doc](https://blurb-books.atlassian.net/wiki/spaces/TEC/pages/4071686150/Codex+Design+System+Implementation).

## Overview

Codex React provides:

- **Design Tokens**: JSON-based token system compiled to CSS custom properties
- **Themeable Components**: Support for multiple brand themes via `data-theme` attributes
- **CSS Modules**: Scoped, maintainable component styles
- **TypeScript**: Full type safety for components and APIs
- **Accessibility**: Built on Base UI primitives where applicable

## Installation

```bash
npm install @blurb/codex-react
```

**Note**: Published to GitHub Packages registry. Configure `.npmrc`:

```
@blurb:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

## Usage

```tsx
import { Button, Modal, setTheme } from '@blurb/codex-react';
import '@blurb/codex-react/styles';

// Set theme (optional, defaults to "base")
setTheme('blurb');

function App() {
  return (
    <>
      <Button variant="filled" intent="brand">Click me</Button>
      <Button variant="outlined" intent="danger">Delete</Button>
    </>
  );
}
```

## Icons

Icons are published in /icons subpath. These are published as react components which render as svg.

### Using

```tsx
import { SearchIcon, KeyboardArrowDownIcon } from '@blurb/codex-react/icons';

<SearchIcon size="lg" label="Search" />  // labeled: role="img" + aria-label
<KeyboardArrowDownIcon />                 // decorative: aria-hidden, inherits text size
```

- `size`: `sm`, `base`, `lg`, `xl`, `2xl`, `3xl`, `4xl`, `5xl`. Omit to inherit the surrounding font size.
- `label`: sets the accessible name. Omit for decorative icons.

### Contributing

#### Material
Material icons are downloaded from the material github https://github.com/google/material-design-icons/tree/master. 

To add a new material icon, add the material symbol name to src/icons/icons.manifest.json. Then run the `npm run icon-gen` script.

For custom icons: add an .svg in the icons/custom directory then run the icon-gen script.

## Fonts

The library only **names** font families via tokens — it never **sources** them
(no `@font-face`, no font binaries). Each theme's `--codex-font-family-*` tokens
resolve to plain family names; the consuming app delivers those faces.

| Theme   | Consumer must load                                                   |
| ------- | -------------------------------------------------------------------- |
| `base`  | nothing — pure system stack                                          |
| `rpa`   | `<link rel="stylesheet" href="https://use.typekit.net/cgs8cau.css">` |
| `blurb` | `<link rel="stylesheet" href="https://use.typekit.net/arj3syy.css">` |

Both brand kits are Adobe Typekit. `rpa`'s kit (`cgs8cau`) registers `sofia-pro` /
`neue-haas-grotesk-display` / `roboto-mono`; `blurb`'s kit (`arj3syy`) registers
`proxima-nova` / `futura-pt` / `roboto-mono` — the exact slugs each theme's tokens
name, so loading the `<link>` is all a consumer needs.

If your provider registers the faces under a **different** name (e.g. an Astro app
that exposes them as `--font-*` vars), override the token directly in CSS loaded
**after** `@blurb/codex-react/styles`:

```css
:root {
  --codex-font-family-heading: var(--font-futura-pt), sans-serif;
}
```

## Development

### Prerequisites

- Node.js 22+

### Getting Started

```bash
# Install dependencies
npm install

# Start Storybook for component development
npm run storybook

# Generate design tokens CSS (only required when tokens JSON changes)
npm run build:tokens
```

### Key Commands

| Command | Description |
|---------|-------------|
| `npm run storybook` | Start Storybook on port 6006 |
| `npm run build` | Full production build |
| `npm run build:tokens` | Generate CSS from design tokens |
| `npm run lint` | Run ESLint |
| `npm run format` | Format code with Prettier |

### Project Structure

```
tokens/              # Design token definitions (JSON)
  base/              # Base token values
  themes/            # Theme-specific overrides
src/
  components/        # React components
  themes/            # Generated CSS from tokens (committed)
  core.css           # Shared global CSS: layer order + theme imports
scripts/             # Helper scripts
```

## Release Process

This project uses automated releases that publish to GitHub Packages when a GitHub release is created.

### Prerequisites

- **Repository Permissions**: Maintainers need permission to bypass branch protection on `main` to push version bump commits directly
- **GitHub Settings**: Settings → Branches → Branch protection rules → "Allow specified actors to bypass required pull requests"

### Creating a Release

1. **Ensure you're on main** with latest changes:

   ```bash
   git checkout main
   git pull
   ```

2. **Run the release script** for the appropriate version bump:

   ```bash
   # For bug fixes (1.0.0 → 1.0.1)
   npm run release:patch

   # For new features (1.0.0 → 1.1.0)
   npm run release:minor

   # For breaking changes (1.0.0 → 2.0.0)
   npm run release:major
   ```

   This will:
   - Run all quality checks (format, lint, tokens, build)
   - Bump the version in `package.json`
   - Create a version bump commit
   - Create a git tag (e.g., `v1.0.1`)
   - Push both the commit and tag to main

3. **Create a GitHub Release**:
   - Go to [Releases](https://github.com/blurb/codex-react/releases) → **Draft a new release**
   - Select the tag that was just pushed (e.g., `v1.0.1`)
   - Add release notes describing the changes
   - Click **Publish release**

4. **Automatic Publishing**:
   - The [Publish workflow](https://github.com/blurb/codex-react/actions/workflows/publish.yml) will automatically trigger
   - It will build and publish the package to GitHub Packages
   - Monitor the workflow to ensure successful publication

### Updating Color Tokens

The parseFigmaTokens scripts can be used to automatically update the tokens and generate new CSS from variables downloaded from the design system Figma. To update the color tokens, do the following:

#### Download the current variables
1. Go to the Codex Design System Figma, and enable dev mode (toggle on the bottom tool tray)
2. In the righthand sidebar under the Variables heading, open the variables table
3. Right click on "Color Primitive", then click "Export modes"
4. Do the same for "Color"
5. Unzip both downloads, and place the unzipped files into a single folder

#### Run the parsing script
Run `./scripts/parseFigmaTokens.sh <path-to-variable-directory>`, passing the path where you put the Figma variable jsons as the first argument

If the format of the color variables changes the script may have to be updated first.

Check the diff to make sure the update worked.